Article title: When Contract Order Becomes API: A Representation-Invariance Audit for OpenAPI SDK Generation
Journal target: Empirical Software Engineering
Author: Huynh Anh Khiem
Affiliation: Faculty of Information Technology, Ton Duc Thang University, Ho Chi Minh City, Vietnam
Corresponding author: huynhanhkhiem@tdtu.edu.vn
ORCID: 0009-0007-7210-174X

ONLINE RESOURCE 1 — REPLICATION AND AUDIT PACKAGE

Purpose
This package supports a bounded audit of representation-order sensitivity in OpenAPI SDK generation. The primary corpus-level observable is a normalized generated-source declaration projection. Equality of that projection is called PROJECTION_INVARIANT; it is not a claim that every generated source byte, documentation file, package export, or runtime behavior is identical.

Primary result files
- results/main_725_projection_results.csv
- results/main_725_pair_projection_results.csv
- results/main_725_summary.json
- results/path_robustness_722_run_results.csv
- results/path_robustness_722_pair_results.csv
- results/path_robustness_722_summary.json
- results/reduced_factorial_summary.json
- results/consumer_witness_summary.json
- results/projection_calibration_summary.json
- results/mitigation_extension/sort_model_properties_7.25.0.csv
- results/mitigation_extension/sort_model_properties_7.22.0_affected_cases.csv
- results/title_repair_summary.json
- results/title_repair_migration.json
- results/sortoutput_preprocess_725.csv
- results/oas_path_ambiguity_screen.csv
- results/near_duplicate_audit.csv
- results/semantic_scope_and_dedup_summary.json
- results/provider_conditioned_design_resolution.csv
- results/spec023_fresh_provenance_audit.json
- results/projection_evidence/
- results/canonicalization_mitigation_pairs.csv
- results/canonicalization_mitigation_summary.json
- results/final_sample_eligibility_audit.csv

Outcome and construct boundary
`projection_record_count` is the number of declaration-bearing source records/files represented in the normalized projection; it is not the number of individual declarations. `PROJECTION_INVARIANT` means only that this projection is unchanged. A targeted clean re-generation audit of spec_023 demonstrates the distinction: all six Python variants regenerate with 127 whole-project files and the same projection hash, while recursive_reverse changes the client-source-tree content hash without changing the projection. For the headline original-versus-reverse_paths comparison in spec_023, both the client-source-tree hash and projection are identical. The submitted main table is rebuilt from empty output directories and records the fresh whole-project file count plus tree-path/tree-content hashes for every run. The earlier development-stage 239-file row is not part of the submitted evidence.

Headline projection result
The 7.25.0 frozen result set contains 480 completed generations and 400 treatment comparisons. Reverse_paths changes the declaration projection for 10/40 contract instances in both Python and TypeScript Fetch. The same ten affected contract IDs reproduce on 7.22.0. Format-only controls are projection-stable in 80/80 contract-backend pairs. These are projection-level findings, not a corpus-wide breaking-change rate.

Semantic-scope sensitivity
OpenAPI allows tooling discretion for ambiguous route matching. A strict OpenAPI path-semantics screen flags four contracts with ambiguous template-template route matching for which tooling discretion can matter: spec_004, spec_013, spec_016, and spec_037. Two are reverse-path drift cases. Excluding these four leaves 8/36 reverse-path drift contracts. Concrete-vs-template overlaps are not excluded because OpenAPI explicitly gives concrete paths precedence. This is a sensitivity analysis, not a claim that the screen exhausts all OpenAPI semantic rules.

Near-duplicate sensitivity
A normalized three-line-shingle screen identifies one pair above the 0.75 similarity threshold: spec_019/spec_034 (Jaccard 0.9555). The raw benchmark therefore contains 39 near-duplicate-collapsed contract families with 9 reverse-path drift families. Combining the strict four-contract ambiguity exclusion with this collapse leaves 35 semantics-clean families and 7 drift families. Fractions are descriptive; no population prevalence is inferred.

Provider-conditioned exploratory screen
Provider clustering makes ordinary contract-level independence implausible. Exact conditioning yields only 126 admissible allocations. For the headline path-local-inline feature, the minimum attainable one-sided p-value is 0.1667, so the design cannot reject at alpha=.05 even at its maximum statistic. The manuscript therefore does not interpret p=.167 as evidence of no association and removes that p-value from the abstract. The structural screen is exploratory only.

Mitigation and prevention
- SORT_MODEL_PROPERTIES is completed, not prospective: on 7.25.0 the same 10/40 contracts remain projection-changed in both backends; on 7.22.0 all 20 affected contract-backend pairs remain changed.
- Explicit titles repair the reduced context-derived naming instability under both path orders in both backends/releases. However, adopting those titles changes the baseline projection in 4/4 release-backend combinations, so title adoption is explicitly treated as a migration event.
- OpenAPI Generator `sortOutput` is an output-sorting option of the openapi/openapi-yaml generators. Direct testing on the ten affected contracts shows that it does not collapse baseline and reverse_paths after resolver processing: all 10/10 emitted intermediate OpenAPI documents remain different in parsed content.
- Custom pre-resolution canonical mapping sorting collapses 200/200 baseline/transformed pairs to identical generator-input bytes, but first adoption changes one baseline projection in 1/40 contracts. It is therefore prevention with a migration boundary, not a compatibility guarantee.

Reduced executable calibration
The reduced 2 x 2 design isolates path order from components.schemas order. In TypeScript, the projected DeleteFleetOperationRequest loss is accompanied by failure of an unchanged consumer on both 7.22.0 and 7.25.0. SOURCE_INCOMPATIBILITY is reserved for this executable witness; corpus-level projection drift is not automatically escalated to breaking-change status.

Sampling provenance boundary
The 40 included contracts are pinned by SHA-256 and re-audited for the stated eligibility criteria. The historical candidate/exclusion log preceding the frozen 40-file benchmark was not retained. The package therefore does not claim a reconstructible probability/systematic sample or estimate population prevalence. The near-duplicate and ambiguity screens are supplied specifically to bound this limitation.

Literature/prior-art boundary
The frozen broad search contains 348 records. Because its original query set did not explicitly include every later-central construct, evidence/targeted_literature_addendum_20260831.txt documents an additional targeted search using ordering, deterministic generation, canonicalization, reproducible builds, inline schema naming, SDK stability, sortOutput, and SORT_MODEL_PROPERTIES terms. This update identified relevant engineering controls and further narrows the novelty claim; it does not retroactively relabel the 348-record search as having contained those queries.

Reproduction
1. Obtain OpenAPI Generator CLI 7.25.0 and 7.22.0 and verify the SHA-256 hashes in TOOL_VERSIONS.txt.
2. Place the JARs under tools/ using the filenames described there. Third-party JARs are intentionally not redistributed.
3. Install requirements.txt and npm dependencies.
4. scripts/reproduce_main_725.py regenerates the 7.25.0 projection result tables.
5. scripts/path_robustness_722.py regenerates reverse-path replication.
6. Run the reduced factorial, consumer witness, mitigation, canonicalization, and projection-evidence scripts as documented in their headers.
7. scripts/verify_results.py performs consistency and targeted provenance checks over the submitted evidence. It is not described as an independent regeneration of all SDK trees.

Artifact boundary
Generated SDK trees and third-party generator JARs are not redistributed. Human-readable projection JSON and unified diffs are included for all 20 backend-pairs of the ten 7.25.0 reverse-path drift contracts. Raw contracts, transformed inputs, manifests, scripts, projection hashes, mitigation outputs, sensitivity screens, and the reduced compiler witness are included for direct audit.
