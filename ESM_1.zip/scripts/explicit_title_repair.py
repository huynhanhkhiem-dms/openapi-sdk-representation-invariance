#!/usr/bin/env python3
from pathlib import Path
import yaml, json, shutil, subprocess, sys, hashlib
sys.path.insert(0,str(Path(__file__).resolve().parent))
import signature_extract
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'data'/'reduced'/'reduced_paths_orig__schemas_orig.yaml'
REV=ROOT/'data'/'reduced'/'reduced_paths_rev__schemas_orig.yaml'
OUTDATA=ROOT/'data'/'reduced_title_repair'; OUTRUN=ROOT/'title_repair_runs'; RES=ROOT/'results'/'title_repair_summary.json'
VERS=('7.22.0','7.25.0'); GENS=('python','typescript-fetch')
TITLES={'/deleteFleet':'DeleteFleetOperationRequest','/describeFleet':'DescribeFleetOperationRequest'}
def load_title(src,dest):
 d=yaml.safe_load(src.read_text())
 for path,title in TITLES.items(): d['paths'][path]['post']['requestBody']['content']['application/json']['schema']['title']=title
 dest.parent.mkdir(parents=True,exist_ok=True); dest.write_text(yaml.safe_dump(d,sort_keys=False),encoding='utf8')
def proj(path,g): return signature_extract.python_signature(path) if g=='python' else signature_extract.typescript_signature(path)
def gen(ver,spec,g,label):
 jar=ROOT/'tools'/f'openapi-generator-cli-{ver}.jar'; out=OUTRUN/ver/label/g
 if out.exists(): shutil.rmtree(out)
 out.mkdir(parents=True)
 cmd=['java','-Xmx640m','-jar',str(jar),'generate','-i',str(spec),'-g',g,'-o',str(out),'--global-property','apiDocs=false,modelDocs=false,apiTests=false,modelTests=false']
 p=subprocess.run(cmd,capture_output=True,text=True,timeout=240)
 if p.returncode: return None,(p.stderr or p.stdout)[-2000:]
 s=proj(out,g); return s,''
def main():
 b=OUTDATA/'baseline_titled.yaml'; r=OUTDATA/'reverse_paths_titled.yaml'; load_title(BASE,b); load_title(REV,r)
 rows=[]
 for ver in VERS:
  for g in GENS:
   sb,e1=gen(ver,b,g,'baseline'); sr,e2=gen(ver,r,g,'reverse_paths')
   rows.append({'version':ver,'generator':g,'baseline_ok':sb is not None,'reverse_ok':sr is not None,'projection_changed': None if sb is None or sr is None else sb!=sr,'baseline_entities':None if sb is None else len(sb),'reverse_entities':None if sr is None else len(sr),'error':e1 or e2})
 # unchanged TS consumer using explicit title-based type
 consumer="""import { DefaultApi, DeleteFleetOperationRequest } from './apis/DefaultApi';\nconst api = new DefaultApi();\nconst req: DeleteFleetOperationRequest = { deleteFleetOperationRequest: { fleet: 'arn:test' } };\nvoid api.deleteFleet(req);\n"""
 tsc=ROOT/'node_modules'/'.bin'/'tsc'; checks=[]
 for ver in VERS:
  for label in ('baseline','reverse_paths'):
   out=OUTRUN/ver/label/'typescript-fetch'; (out/'consumer_title_repair.ts').write_text(consumer,encoding='utf8')
   p=subprocess.run([str(tsc if tsc.exists() else 'tsc'),'--noEmit','--target','ES2020','--module','commonjs','--lib','ES2020,DOM','--skipLibCheck','consumer_title_repair.ts'],cwd=out,capture_output=True,text=True,timeout=180)
   checks.append({'version':ver,'variant':label,'exit_code':p.returncode,'stderr':p.stderr[-1000:],'stdout':p.stdout[-1000:]})
 out={'repair':'explicit title on each inline request schema','projection_checks':rows,'consumer_source':consumer,'typescript_consumer_checks':checks,'all_projection_invariant':all(x['projection_changed'] is False for x in rows),'all_consumer_compile':all(x['exit_code']==0 for x in checks)}
 RES.write_text(json.dumps(out,indent=2)+'\n',encoding='utf8'); print(json.dumps(out,indent=2))
if __name__=='__main__': main()
