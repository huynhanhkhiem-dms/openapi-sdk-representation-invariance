from pathlib import Path
import csv,re,itertools,json
ROOT=Path(__file__).resolve().parents[1]; RAW=ROOT/'data/raw_specs'; R=ROOT/'results'
DRIFT={'spec_009','spec_012','spec_013','spec_017','spec_019','spec_025','spec_034','spec_036','spec_037','spec_038'}

def extract_paths(text):
    lines=text.splitlines(); in_paths=False; base=0; out=[]
    for line in lines:
        if not in_paths:
            m=re.match(r'^(\s*)paths:\s*(?:#.*)?$',line)
            if m: in_paths=True; base=len(m.group(1)); continue
        else:
            if not line.strip() or line.lstrip().startswith('#'): continue
            indent=len(line)-len(line.lstrip(' '))
            if indent<=base: break
            if indent==base+2:
                s=line.strip(); m=re.match(r'(?:(?:"([^"]+)")|(?:\'([^\']+)\')|([^:]+)):\s*',s)
                if m:
                    key=next(x for x in m.groups() if x is not None).strip()
                    if key.startswith('/'): out.append(key)
    return out

def segs(p): return [x for x in p.strip('/').split('/') if x!='']
def param(x): return x.startswith('{') and x.endswith('}')
def can_overlap(a,b):
    A,B=segs(a),segs(b)
    return len(A)==len(B) and all(param(x) or param(y) or x==y for x,y in zip(A,B))
def shape(p): return tuple('{}' if param(x) else x for x in segs(p))
def classify(a,b):
    A,B=segs(a),segs(b); ta=sum(param(x) for x in A); tb=sum(param(x) for x in B)
    if ta==0 or tb==0: return 'concrete_template_precedence'
    if shape(a)==shape(b): return 'equivalent_template_shape'
    return 'ambiguous_template_overlap'
rows=[]; summary=[]
for p in sorted(RAW.glob('spec_*.yaml')):
    sid=p.stem; paths=extract_paths(p.read_text(encoding='utf-8',errors='replace')); kinds=[]
    for a,b in itertools.combinations(paths,2):
        if can_overlap(a,b):
            k=classify(a,b); kinds.append(k); rows.append({'sample_id':sid,'overlap_type':k,'path_a':a,'path_b':b})
    summary.append({'sample_id':sid,'path_count':len(paths),'concrete_template_pairs':kinds.count('concrete_template_precedence'),'ambiguous_template_pairs':kinds.count('ambiguous_template_overlap'),'equivalent_template_shape_pairs':kinds.count('equivalent_template_shape'),'reverse_path_projection_drift':sid in DRIFT})
for fn,data in [('oas_path_semantics_pairs.csv',rows),('oas_path_ambiguity_screen.csv',summary)]:
    with (R/fn).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=data[0].keys()); w.writeheader(); w.writerows(data)
amb={x['sample_id'] for x in summary if x['ambiguous_template_pairs']>0}
clean=[x['sample_id'] for x in summary if x['sample_id'] not in amb]
clean_drift=sorted(DRIFT-set(amb))
out={'screen_definition':'A strict syntactic screen for the OAS case where two templated paths can match the same concrete URL and neither is a fully concrete path. Concrete-vs-template overlaps are recorded separately because OAS explicitly gives concrete paths precedence. Equivalent template shapes are recorded separately as specification-validity concerns.','ambiguous_template_overlap_contracts':len(amb),'ambiguous_template_overlap_ids':sorted(amb),'reverse_path_drift_contracts_with_ambiguous_template_overlap':sorted(DRIFT&amb),'semantics_clean_contracts':len(clean),'semantics_clean_reverse_path_drift_contracts':len(clean_drift),'semantics_clean_drift_ids':clean_drift}
(R/'oas_path_semantics_summary.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,indent=2))
