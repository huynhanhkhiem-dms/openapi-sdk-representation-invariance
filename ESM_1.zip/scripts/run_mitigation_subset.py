import sys, json, csv, hashlib, shutil, subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
sys.path.insert(0,str(Path(__file__).resolve().parent))
import signature_extract
ROOT=Path(__file__).resolve().parents[1]; VAR=ROOT/'data'/'main_variants'; OUT=ROOT/'results'/'mitigation_extension'; GENS=('python','typescript-fetch')
def vp(sid,v):
 p=list(VAR.glob(f'{sid}__{v}.*')); assert len(p)==1; return p[0]
def sig(out,g): return signature_extract.python_signature(out) if g=='python' else signature_extract.typescript_signature(out)
def gen(jar,sid,v,g,c):
 out=ROOT/'mitigation_runs'/jar.stem/c/sid/v/g
 if out.exists(): shutil.rmtree(out)
 out.mkdir(parents=True)
 cmd=['java','-Xmx512m','-jar',str(jar),'generate','-i',str(vp(sid,v)),'-g',g,'-o',str(out),'--global-property','apiDocs=false,modelDocs=false,apiTests=false,modelTests=false']
 if c=='sort_model_properties': cmd += ['--openapi-normalizer','SORT_MODEL_PROPERTIES=true']
 p=subprocess.run(cmd,capture_output=True,text=True,timeout=240)
 if p.returncode: return {'ok':False,'error':(p.stderr or p.stdout)[-1500:]}
 s=sig(out,g); payload=json.dumps(s,ensure_ascii=False,sort_keys=True,separators=(',',':'))
 return {'ok':True,'signature_sha256':hashlib.sha256(payload.encode()).hexdigest(),'projection_records':len(s)}
def pair(task):
 jar,sid,g,c=task; b=gen(jar,sid,'original',g,c); r=gen(jar,sid,'reverse_paths',g,c)
 return {'config':c,'sample_id':sid,'generator':g,'baseline_ok':b.get('ok',False),'reverse_ok':r.get('ok',False),'signature_changed':bool(b.get('ok') and r.get('ok') and b['signature_sha256']!=r['signature_sha256']),'projection_record_count_change':(r.get('projection_records',0)-b.get('projection_records',0)) if b.get('ok') and r.get('ok') else '', 'baseline_signature_sha256':b.get('signature_sha256',''),'reverse_signature_sha256':r.get('signature_sha256',''),'error':b.get('error','') or r.get('error','')}
if __name__=='__main__':
 ver=sys.argv[1]; label=sys.argv[2]; sids=sys.argv[3:]; jar=ROOT/'tools'/f'openapi-generator-cli-{ver}.jar'; configs=tuple(__import__('os').environ.get('CONFIGS','default,sort_model_properties').split(',')); tasks=[(jar,s,g,c) for c in configs for s in sids for g in GENS]
 rows=[]
 with ThreadPoolExecutor(max_workers=4) as ex:
  futs=[ex.submit(pair,t) for t in tasks]
  for f in as_completed(futs): rows.append(f.result())
 rows=sorted(rows,key=lambda x:(x['config'],x['sample_id'],x['generator']))
 OUT.mkdir(parents=True,exist_ok=True); fn=OUT/f'subset_{ver}_{label}.csv'
 with fn.open('w',newline='',encoding='utf8') as f: w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 sm={}
 for c in configs:
  ss=[x for x in rows if x['config']==c];sm[c]={'backend_pairs':len(ss),'failures':sum(not(x['baseline_ok'] and x['reverse_ok']) for x in ss),'changed_backend_pairs':sum(x['signature_changed'] for x in ss),'changed_specs':sorted({x['sample_id'] for x in ss if x['signature_changed']})}
 print(json.dumps(sm,indent=2))
