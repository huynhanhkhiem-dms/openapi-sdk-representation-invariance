#!/usr/bin/env python3
"""Mitigation extension for CRI path-order drift.

This script tests a documented generator-side option against exactly the same
source-order-preserving baseline/reverse_paths treatment. It is deliberately kept
separate from the submitted main experiment because mitigation effectiveness was
not part of the original frozen result set.

Important scope note: OpenAPI Generator documents SORT_MODEL_PROPERTIES as sorting
model properties; it is not documented as a top-level paths canonicalizer. A null
mitigation effect is therefore scientifically informative rather than a test failure.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import signature_extract  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
VARIANTS = ROOT / "data" / "main_variants"
OUT = ROOT / "results" / "mitigation_extension"
GENERATORS = ("python", "typescript-fetch")


def variant_path(sid: str, variant: str) -> Path:
    hits = list(VARIANTS.glob(f"{sid}__{variant}.*"))
    if len(hits) != 1:
        raise RuntimeError(f"Expected exactly one {sid}/{variant} variant")
    return hits[0]


def sig(out: Path, gen: str) -> dict:
    return signature_extract.python_signature(out) if gen == "python" else signature_extract.typescript_signature(out)


def run(jar: Path, sid: str, variant: str, gen: str, config: str) -> dict:
    spec = variant_path(sid, variant)
    runout = ROOT / "mitigation_runs" / jar.stem / config / sid / variant / gen
    if runout.exists(): shutil.rmtree(runout)
    runout.mkdir(parents=True)
    cmd = ["java", "-Xmx640m", "-jar", str(jar), "generate", "-i", str(spec), "-g", gen, "-o", str(runout),
           "--global-property", "apiDocs=false,modelDocs=false,apiTests=false,modelTests=false"]
    if config == "sort_model_properties":
        cmd += ["--openapi-normalizer", "SORT_MODEL_PROPERTIES=true"]
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=240)
    if p.returncode:
        return {"ok": False, "error": (p.stderr or p.stdout)[-1500:]}
    s = sig(runout, gen)
    payload = json.dumps(s, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return {"ok": True, "signature_sha256": hashlib.sha256(payload.encode()).hexdigest(), "projection_records": len(s)}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--version", default="7.25.0")
    args = ap.parse_args()
    jar = ROOT / "tools" / f"openapi-generator-cli-{args.version}.jar"
    if not jar.exists(): raise SystemExit(f"Missing {jar}; provide the pinned JAR first.")
    sids = [f"spec_{i:03d}" for i in range(1, 41)]
    rows = []
    for config in ("default", "sort_model_properties"):
        for sid in sids:
            for gen in GENERATORS:
                b = run(jar, sid, "original", gen, config)
                r = run(jar, sid, "reverse_paths", gen, config)
                rows.append({
                    "version": args.version, "config": config, "sample_id": sid, "generator": gen,
                    "baseline_ok": b.get("ok", False), "reverse_ok": r.get("ok", False),
                    "signature_changed": bool(b.get("ok") and r.get("ok") and b["signature_sha256"] != r["signature_sha256"]),
                    "projection_record_count_change": (r.get("projection_records", 0) - b.get("projection_records", 0)) if b.get("ok") and r.get("ok") else "",
                    "baseline_signature_sha256": b.get("signature_sha256", ""),
                    "reverse_signature_sha256": r.get("signature_sha256", ""),
                    "error": b.get("error", "") or r.get("error", ""),
                })
    OUT.mkdir(parents=True, exist_ok=True)
    csv_path = OUT / f"sort_model_properties_{args.version}.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    summary = {}
    for config in ("default", "sort_model_properties"):
        ss = [x for x in rows if x["config"] == config]
        summary[config] = {
            "backend_pairs": len(ss),
            "generation_failures": sum(not (x["baseline_ok"] and x["reverse_ok"]) for x in ss),
            "changed_backend_pairs": sum(x["signature_changed"] for x in ss),
            "changed_specs": sorted({x["sample_id"] for x in ss if x["signature_changed"]}),
        }
    (OUT / f"sort_model_properties_{args.version}_summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
