#!/usr/bin/env python3
"""Calibrate the declaration-projection outcome against the executable TypeScript witness.

This is deliberately a reduced-case calibration, not a corpus-wide estimate of consumer breakage
and not a package-root export audit. The unchanged consumer imports the generated DefaultApi module.
"""
from __future__ import annotations
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RES=ROOT/'results'
red=json.loads((RES/'reduced_factorial_summary.json').read_text(encoding='utf-8'))
wit=json.loads((RES/'consumer_witness_summary.json').read_text(encoding='utf-8'))
checks=[]
for version in ('7.22.0','7.25.0'):
    c=red['causal_pattern'][version]['typescript-fetch']
    base=set(c['baseline_evidence'])
    rev=set(c['path_only_evidence'])
    w=next(x for x in wit['checks'] if x['version']==version)
    base_has=any(x=='interface DeleteFleetOperationRequest' for x in base)
    rev_has=any(x=='interface DeleteFleetOperationRequest' for x in rev)
    rev_alt=any(x=='interface DescribeFleetOperationRequest' for x in rev)
    compile_break=(w['baseline']['exit_code']==0 and w['path_reversed']['exit_code']!=0)
    err=(w['path_reversed'].get('stdout','')+'\n'+w['path_reversed'].get('stderr',''))
    missing_named=('DeleteFleetOperationRequest' in err and ('no exported member' in err or 'TS2724' in err))
    checks.append({
      'version':version,
      'baseline_projection_contains_DeleteFleetOperationRequest':base_has,
      'path_reversed_projection_contains_DeleteFleetOperationRequest':rev_has,
      'path_reversed_projection_contains_DescribeFleetOperationRequest':rev_alt,
      'unchanged_consumer_baseline_exit_code':w['baseline']['exit_code'],
      'unchanged_consumer_path_reversed_exit_code':w['path_reversed']['exit_code'],
      'compiler_error_names_missing_baseline_interface':missing_named,
      'projection_consumer_concordance': bool(base_has and not rev_has and rev_alt and compile_break and missing_named),
    })
out={
  'analysis':'reduced declaration-projection to consumer-failure calibration',
  'scope':'TypeScript reduced witness importing the generated ./apis/DefaultApi module; not a corpus-wide breakage estimate and not package-root export validation',
  'checks':checks,
  'all_versions_concordant':all(x['projection_consumer_concordance'] for x in checks),
  'interpretation':'The reduced case calibrates the direction of the declaration projection against an executable source consumer on two generator releases. It does not establish that every corpus-level declaration drift is a package-level breaking change.'
}
(RES/'projection_calibration_summary.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2))
