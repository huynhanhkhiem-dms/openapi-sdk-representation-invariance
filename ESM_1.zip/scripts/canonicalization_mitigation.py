#!/usr/bin/env python3
"""Verify canonicalization as a preventive mitigation for mapping-order transformations.

Canonicalization is tested as a preprocessing policy, not as a claim that switching an
already-published SDK to canonical order is backward compatible.
"""
from __future__ import annotations
import copy, datetime as dt, hashlib, json
from pathlib import Path
import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw_specs"
RES = ROOT / "results"


def normalize_scalars(value):
    if isinstance(value, dict): return {k: normalize_scalars(v) for k, v in value.items()}
    if isinstance(value, list): return [normalize_scalars(v) for v in value]
    if isinstance(value, (dt.date, dt.datetime)): return value.isoformat()
    return value

def reverse_dict(d): return {k: v for k, v in reversed(list(d.items()))}
def recursive_reverse(value):
    if isinstance(value, dict): return {k: recursive_reverse(v) for k, v in reversed(list(value.items()))}
    if isinstance(value, list): return [recursive_reverse(v) for v in value]
    return value

def sorted_mappings(value):
    if isinstance(value, dict): return {k: sorted_mappings(value[k]) for k in sorted(value)}
    if isinstance(value, list): return [sorted_mappings(v) for v in value]
    return value

def canonical_bytes(doc):
    return json.dumps(sorted_mappings(normalize_scalars(doc)), ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()

def variants(doc):
    rp = copy.deepcopy(doc); rp["paths"] = reverse_dict(rp.get("paths") or {})
    rs = copy.deepcopy(doc); rs.setdefault("components", {})["schemas"] = reverse_dict((rs.get("components") or {}).get("schemas") or {})
    return {"format_json": copy.deepcopy(doc), "reverse_paths": rp, "reverse_component_schemas": rs,
            "recursive_reverse": recursive_reverse(doc), "canonical_sorted": sorted_mappings(doc)}

def main():
    rows=[]
    for source in sorted(RAW.glob("spec_*.yaml")):
        doc=normalize_scalars(yaml.safe_load(source.read_text(encoding="utf-8")))
        base=canonical_bytes(doc); base_hash=hashlib.sha256(base).hexdigest()
        for name,v in variants(doc).items():
            cb=canonical_bytes(v); rows.append({"sample_id":source.stem,"variant":name,
                "canonical_input_sha256":hashlib.sha256(cb).hexdigest(),"matches_original_canonical_input":cb==base})
    df=pd.DataFrame(rows); df.to_csv(RES/'canonicalization_mitigation_pairs.csv',index=False)
    pair=pd.read_csv(RES/'main_725_pair_results.csv')
    c=pair[pair.variant.eq('canonical_sorted')]
    changed=c.assign(_changed=c.signature_changed.astype(str).str.lower().eq('true')).groupby('sample_id')._changed.max()
    summary={
      "mitigation":"canonicalize all mapping keys recursively before generation",
      "specifications":40,
      "transformation_pairs":int(len(df)),
      "canonicalized_pairs_with_identical_generator_input":int(df.matches_original_canonical_input.sum()),
      "canonicalized_pairs_with_different_generator_input":int((~df.matches_original_canonical_input).sum()),
      "one_time_migration_surface_changes_vs_author_order":int(changed.sum()),
      "specifications_evaluated_for_one_time_migration":int(len(changed)),
      "interpretation":"For the five tested representation transformations, canonical preprocessing collapses every original/transformed pair to identical generator input bytes. However, adopting canonical order can itself be a one-time SDK migration: the existing canonical_sorted experiment differs from the source-order-preserving baseline for 1 of 40 contracts."
    }
    (RES/'canonicalization_mitigation_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
