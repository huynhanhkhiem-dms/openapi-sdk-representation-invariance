#!/usr/bin/env node
/** Extract a deterministic declaration projection from generated TypeScript.
 * Uses the TypeScript compiler parser; no type checking is required.
 * This is a syntactic source-file projection, not a recursive package-entrypoint export resolver.
 */
const fs = require('fs');
const path = require('path');
const ts = require('typescript');

const root = path.resolve(process.argv[2] || '.');

function walk(dir) {
  let out = [];
  for (const ent of fs.readdirSync(dir, {withFileTypes:true})) {
    if (ent.name === 'node_modules' || ent.name === '.openapi-generator' || ent.name === 'test' || ent.name === 'tests') continue;
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) out = out.concat(walk(p));
    else if (ent.isFile() && p.endsWith('.ts') && !p.endsWith('.d.ts')) out.push(p);
  }
  return out.sort();
}

function compact(s) { return s.replace(/\s+/g,' ').trim(); }
function hasModifier(node, kind) { return !!node.modifiers?.some(m => m.kind === kind); }
function isExported(node) { return hasModifier(node, ts.SyntaxKind.ExportKeyword) || hasModifier(node, ts.SyntaxKind.DefaultKeyword); }
function isPrivate(node) { return hasModifier(node, ts.SyntaxKind.PrivateKeyword) || hasModifier(node, ts.SyntaxKind.ProtectedKeyword); }
function nameText(n, sf) {
  if (!n) return '';
  if (ts.isIdentifier(n) || ts.isPrivateIdentifier(n)) return n.text;
  if (ts.isStringLiteral(n) || ts.isNumericLiteral(n)) return n.text;
  return compact(n.getText(sf));
}
function typeText(t, sf) { return t ? compact(t.getText(sf)) : '<inferred>'; }
function paramText(p, sf) {
  const dots = p.dotDotDotToken ? '...' : '';
  const q = p.questionToken ? '?' : '';
  const init = p.initializer ? '=default' : '';
  return `${dots}${nameText(p.name,sf)}${q}:${typeText(p.type,sf)}${init}`;
}
function typeParams(node, sf) {
  if (!node.typeParameters?.length) return '';
  return '<' + node.typeParameters.map(x => compact(x.getText(sf))).join(',') + '>';
}
function heritage(node, sf) {
  if (!node.heritageClauses?.length) return [];
  return node.heritageClauses.map(h => compact(h.getText(sf))).sort();
}
function methodSig(m, sf) {
  const n = nameText(m.name,sf);
  const q = m.questionToken ? '?' : '';
  const params = (m.parameters || []).map(p => paramText(p,sf)).join(',');
  return `${n}${q}${typeParams(m,sf)}(${params}):${typeText(m.type,sf)}`;
}
function propertySig(m, sf) {
  const ro = hasModifier(m, ts.SyntaxKind.ReadonlyKeyword) ? 'readonly ' : '';
  const q = m.questionToken ? '?' : '';
  return `${ro}${nameText(m.name,sf)}${q}:${typeText(m.type,sf)}`;
}
function memberSigs(members, sf) {
  const arr = [];
  for (const m of members || []) {
    if (isPrivate(m)) continue;
    if (ts.isPropertyDeclaration(m) || ts.isPropertySignature(m)) arr.push('property ' + propertySig(m,sf));
    else if (ts.isMethodDeclaration(m) || ts.isMethodSignature(m)) arr.push('method ' + methodSig(m,sf));
    else if (ts.isConstructorDeclaration(m)) arr.push('constructor(' + m.parameters.map(p=>paramText(p,sf)).join(',') + ')');
    else if (ts.isGetAccessorDeclaration(m)) arr.push(`get ${nameText(m.name,sf)}:${typeText(m.type,sf)}`);
    else if (ts.isSetAccessorDeclaration(m)) arr.push(`set ${nameText(m.name,sf)}(${m.parameters.map(p=>paramText(p,sf)).join(',')})`);
    else if (ts.isCallSignatureDeclaration(m)) arr.push('call ' + methodSig(m,sf));
    else if (ts.isIndexSignatureDeclaration(m)) arr.push('index(' + m.parameters.map(p=>paramText(p,sf)).join(',') + '):' + typeText(m.type,sf));
  }
  return [...new Set(arr)].sort();
}

const result = {};
for (const file of walk(root)) {
  const text = fs.readFileSync(file,'utf8');
  const sf = ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  const decls = {};
  for (const n of sf.statements) {
    if (!isExported(n)) continue;
    if (ts.isInterfaceDeclaration(n)) {
      decls[`interface ${n.name.text}${typeParams(n,sf)}`] = {heritage: heritage(n,sf), members: memberSigs(n.members,sf)};
    } else if (ts.isClassDeclaration(n) && n.name) {
      decls[`class ${n.name.text}${typeParams(n,sf)}`] = {heritage: heritage(n,sf), members: memberSigs(n.members,sf)};
    } else if (ts.isFunctionDeclaration(n) && n.name) {
      decls[`function ${n.name.text}${typeParams(n,sf)}(${n.parameters.map(p=>paramText(p,sf)).join(',')}):${typeText(n.type,sf)}`] = true;
    } else if (ts.isTypeAliasDeclaration(n)) {
      decls[`type ${n.name.text}${typeParams(n,sf)}=${compact(n.type.getText(sf))}`] = true;
    } else if (ts.isEnumDeclaration(n)) {
      decls[`enum ${n.name.text}`] = n.members.map(m => {
        const val = m.initializer ? '=' + compact(m.initializer.getText(sf)) : '';
        return nameText(m.name,sf) + val;
      }).sort();
    } else if (ts.isVariableStatement(n)) {
      for (const d of n.declarationList.declarations) {
        decls[`variable ${nameText(d.name,sf)}:${typeText(d.type,sf)}`] = true;
      }
    }
  }
  if (Object.keys(decls).length) result[path.relative(root,file).split(path.sep).join('/')] = decls;
}
process.stdout.write(JSON.stringify(result));
