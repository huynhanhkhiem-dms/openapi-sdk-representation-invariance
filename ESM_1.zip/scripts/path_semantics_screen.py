#!/usr/bin/env python3
from pathlib import Path
import json,csv,itertools
ROOT=Path(__file__).resolve().parents[1]
VAR=ROOT/'data'/'main_variants'; OUT=ROOT/'results'
def segs(p): return [s for s in p.strip('/').split('/') if s!='']
def isvar(s): return s.startswith('{') and s.endswith('}')
def overlap(a,b):
 A,B=segs(a),segs(b)
 return len(A)==len(B) and all(isvar(x) or isvar(y) or x==y for x,y in zip(A,B))
def patt(p): return tuple('{}' if isvar(s) else s for s in segs(p))
rows=[]; summary=[]
for i in range(1,41):
 sid=f'spec_{i:03d}'; d=json.loads((VAR/f'{sid}__canonical_sorted.json').read_text(encoding='utf-8')); paths=list((d.get('paths') or {}).keys())
 concrete_template=0; templated_ambiguous=0; invalid_same_hierarchy=0
 for a,b in itertools.combinations(paths,2):
  if not overlap(a,b): continue
  av=any(isvar(s) for s in segs(a)); bv=any(isvar(s) for s in segs(b))
  if not (av and bv):
   concrete_template+=1; kind='concrete_template_overlap'
  elif patt(a)==patt(b):
   invalid_same_hierarchy+=1; kind='same_hierarchy_template_pair'
  else:
   templated_ambiguous+=1; kind='templated_ambiguous_pair'
  rows.append({'sample_id':sid,'kind':kind,'path_a':a,'path_b':b})
 summary.append({'sample_id':sid,'path_count':len(paths),'concrete_template_overlaps':concrete_template,'templated_ambiguous_pairs':templated_ambiguous,'same_hierarchy_template_pairs':invalid_same_hierarchy,'strict_oas_ambiguity_free':templated_ambiguous==0})
with (OUT/'path_semantics_pairs.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
with (OUT/'path_semantics_screen.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=summary[0].keys());w.writeheader();w.writerows(summary)
print('templated ambiguous specs:',[(r['sample_id'],r['templated_ambiguous_pairs']) for r in summary if r['templated_ambiguous_pairs']])
