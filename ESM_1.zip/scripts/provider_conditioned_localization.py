#!/usr/bin/env python3
"""Provider-conditioned sensitivity analysis for exploratory mechanism localization.

This analysis conditions on the observed number of reverse-path drift cases within each
provider and enumerates all label allocations compatible with those provider totals.
It is a sensitivity analysis for provider clustering, not a population inference.
"""
from __future__ import annotations
import itertools, json, math
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
MAN=ROOT/'data'/'data_manifest.csv'
LOC=ROOT/'results'/'mechanism_localization.csv'
OUTCSV=ROOT/'results'/'provider_conditioned_localization.csv'
OUTJSON=ROOT/'results'/'provider_conditioned_localization_summary.json'

m=pd.read_csv(MAN)
f=pd.read_csv(LOC)
d=m.merge(f,on='sample_id',validate='one_to_one')
d['provider']=d['repository_path'].str.extract(r'APIs/([^/]+)/',expand=False)
feature_cols={
    'any_path_local_inline_model':'path_local_inline_models',
    'any_request_inline_model':'request_inline_models',
    'any_cross_path_duplicate_model_group':'cross_path_duplicate_model_groups',
}
for name,col in feature_cols.items():
    d[name]=(d[col].fillna(0).astype(float)>0).astype(int)

provider_blocks=[]
for provider,g in d.groupby('provider',sort=True):
    indices=list(g.index)
    k=int(g['path_drift'].sum())
    combos=list(itertools.combinations(indices,k))
    provider_blocks.append((provider,indices,k,combos))

n_assignments=math.prod(len(b[3]) for b in provider_blocks)
# Exact enumeration is small here (126 assignments).
if n_assignments>1_000_000:
    raise RuntimeError(f'too many exact assignments: {n_assignments}')

assignments=[]
for prod in itertools.product(*[b[3] for b in provider_blocks]):
    y=np.zeros(len(d),dtype=int)
    for chosen in prod:
        y[list(chosen)]=1
    assignments.append(y)

observed=d['path_drift'].to_numpy(dtype=int)
rows=[]
for name in feature_cols:
    x=d[name].to_numpy(dtype=int)
    def stat(y):
        return float(x[y==1].mean()-x[y==0].mean())
    obs=stat(observed)
    null=np.array([stat(y) for y in assignments])
    p_upper=float(np.mean(null>=obs-1e-12))
    p_two=float(np.mean(np.abs(null)>=abs(obs)-1e-12))
    tp=int(((x==1)&(observed==1)).sum()); fp=int(((x==1)&(observed==0)).sum())
    tn=int(((x==0)&(observed==0)).sum()); fn=int(((x==0)&(observed==1)).sum())
    sens=tp/(tp+fn) if tp+fn else None
    spec=tn/(tn+fp) if tn+fp else None
    ppv=tp/(tp+fp) if tp+fp else None
    npv=tn/(tn+fn) if tn+fn else None
    bal=(sens+spec)/2 if sens is not None and spec is not None else None
    denom=(tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)
    mcc=((tp*tn-fp*fn)/math.sqrt(denom)) if denom else None
    rows.append({
        'feature':name,'tp':tp,'fp':fp,'tn':tn,'fn':fn,
        'sensitivity_within_benchmark':sens,'specificity_within_benchmark':spec,
        'ppv_within_benchmark':ppv,'npv_within_benchmark':npv,
        'balanced_accuracy_within_benchmark':bal,'mcc_within_benchmark':mcc,
        'observed_drift_minus_stable_prevalence_difference':obs,
        'provider_conditioned_exact_assignments':n_assignments,
        'provider_conditioned_one_sided_p':p_upper,
        'provider_conditioned_two_sided_p':p_two,
    })

pd.DataFrame(rows).to_csv(OUTCSV,index=False)
summary={
    'analysis_status':'post_hoc_provider_conditioned_sensitivity',
    'conditioning':'preserve the observed number of drift cases within every provider and enumerate all compatible contract-level label assignments',
    'provider_count':int(d.provider.nunique()),
    'mixed_outcome_providers':sorted([p for p,g in d.groupby('provider') if g.path_drift.nunique()>1]),
    'exact_assignment_count':int(n_assignments),
    'tests':rows,
    'interpretation':(
        'The large unstratified Fisher associations are not independently confirmed after conditioning on provider. '
        'The inline-model features remain useful descriptive screening signals within this fixed benchmark, but provider clustering prevents treating them as validated predictive risk factors. '
        'Causal evidence is therefore reserved for the reduced factorial experiment.'
    )
}
OUTJSON.write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
