#!/usr/bin/env python3
"""Validation summary for the Contract Representation Invariance (CRI) audit protocol.

The protocol separates four decisions:
1) treatment validity (canonical parsed equality),
2) declaration-projection invariance,
3) declaration drift,
4) source incompatibility, which requires an executable unchanged-consumer witness.

This script summarizes measurement repeatability and control behavior from submitted results.
"""
from __future__ import annotations
import csv,json,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RES=ROOT/'results'
OUT=RES/'cri_protocol_validation.json'

def asbool(x): return str(x).strip().lower() in {'1','true','yes'}
def readcsv(name):
    with open(RES/name,newline='',encoding='utf-8') as f:return list(csv.DictReader(f))

main_pairs=readcsv('main_725_pair_projection_results.csv')
path722=readcsv('path_robustness_722_pair_results.csv')
consumer=json.loads((RES/'consumer_witness_summary.json').read_text())
reduced=json.loads((RES/'reduced_factorial_summary.json').read_text())
calibration=json.loads((RES/'projection_calibration_summary.json').read_text())

# Treatment validity: all submitted comparison pairs must have semantic-equivalence checks pass.
treatment_pairs=len(main_pairs)
treatment_pass=sum(asbool(r['semantic_hash_matches_baseline']) for r in main_pairs)

# Negative control at contract x backend level.
fmt=[r for r in main_pairs if r['variant']=='format_json']
fmt_stable=sum(not asbool(r['projection_changed']) for r in fmt)

# Path-order classification agreement across backends on 7.25.0.
def changed_set(rows,gen=None):
    return {r['sample_id'] for r in rows if (gen is None or r['generator']==gen) and asbool(r['projection_changed'])}
path25=[r for r in main_pairs if r['variant']=='reverse_paths']
py25=changed_set(path25,'python'); ts25=changed_set(path25,'typescript-fetch')
py22=changed_set(path722,'python'); ts22=changed_set(path722,'typescript-fetch')

def jaccard(a,b): return len(a&b)/len(a|b) if a|b else 1.0

def agreement_binary(a,b,universe):
    av=[x in a for x in universe]; bv=[x in b for x in universe]
    po=sum(x==y for x,y in zip(av,bv))/len(universe)
    pa=sum(av)/len(universe); pb=sum(bv)/len(universe)
    pe=pa*pb+(1-pa)*(1-pb)
    k=(po-pe)/(1-pe) if pe<1 else 1.0
    return po,k
universe=sorted({r['sample_id'] for r in path25})
po_backend,k_backend=agreement_binary(py25,ts25,universe)
po_release_py,k_release_py=agreement_binary(py25,py22,universe)
po_release_ts,k_release_ts=agreement_binary(ts25,ts22,universe)

# Reduced factorial classification pattern from summary.
checks=reduced.get('checks',[])
# group by version/generator and ensure schema-only stable, path-only changed, joint changed
factorial_groups={}
for r in checks:
    key=(r['version'],r['generator'])
    factorial_groups.setdefault(key,{})[r['case']]=bool(r['changed_vs_baseline'])
expected={'paths_orig__schemas_orig':False,'paths_orig__schemas_rev':False,'paths_rev__schemas_orig':True,'paths_rev__schemas_rev':True}
factorial_pass=sum(all(g.get(k)==v for k,v in expected.items()) for g in factorial_groups.values())

consumer_pass=sum(bool(c.get('witness_break')) and c['baseline']['exit_code']==0 and c['path_reversed']['exit_code']!=0 for c in consumer['checks'])

summary={
  'scholarly_object':'Contract Representation Invariance (CRI) audit protocol',
  'decision_states':[
      'INVALID_TREATMENT: canonical parsed values differ',
      'PROJECTION_INVARIANT: canonical parsed values match and normalized declaration projections match',
      'DECLARATION_DRIFT: canonical parsed values match but normalized declaration projections differ',
      'SOURCE_INCOMPATIBILITY: declaration drift is accompanied by failure of an unchanged executable consumer witness'
  ],
  'validation':{
      'semantic_equivalence_treatment_checks':{'passed':treatment_pass,'total':treatment_pairs},
      'format_only_negative_control':{'stable_backend_pairs':fmt_stable,'total_backend_pairs':len(fmt)},
      'reverse_paths_backend_agreement_725':{'python_changed':sorted(py25),'typescript_changed':sorted(ts25),'observed_agreement':po_backend,'cohen_kappa':k_backend,'jaccard_changed_sets':jaccard(py25,ts25)},
      'reverse_paths_cross_release_agreement_python':{'observed_agreement':po_release_py,'cohen_kappa':k_release_py,'jaccard_changed_sets':jaccard(py25,py22)},
      'reverse_paths_cross_release_agreement_typescript':{'observed_agreement':po_release_ts,'cohen_kappa':k_release_ts,'jaccard_changed_sets':jaccard(ts25,ts22)},
      'reduced_factorial_expected_pattern_groups':{'passed':factorial_pass,'total':len(factorial_groups)},
      'unchanged_consumer_witness_versions':{'passed':consumer_pass,'total':len(consumer['checks'])},
      'reduced_projection_consumer_calibration':{'passed':sum(bool(x['projection_consumer_concordance']) for x in calibration['checks']),'total':len(calibration['checks'])}
  },
  'interpretation':(
      'These checks verify treatment integrity, control behavior, and within-family repeatability of the audit procedure: '
      'the equivalence gate never admits a nonequivalent treatment, the format-only negative control is stable, the localized path classification is exactly repeatable across two backends and two releases, and the reduced calibration shows that one declaration-drift mechanism corresponds to an executable generated-module source incompatibility on both tested releases. '
      'They do not validate the declaration projection as a complete package-level API model and do not establish cross-generator external validity.'
  )
}
OUT.write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
