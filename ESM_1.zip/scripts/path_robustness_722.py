#!/usr/bin/env python3
"""Reproduce reverse-path robustness on OpenAPI Generator 7.22.0."""
from __future__ import annotations
import concurrent.futures
import copy
import csv
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
import signature_extract

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw_specs"
VAR = ROOT / "data" / "path_variants_722"
OUT = ROOT / "path_robustness_722_runs"
RES = ROOT / "results"
JAR = ROOT / "tools" / "openapi-generator-cli-7.22.0.jar"
GENS = ("python", "typescript-fetch")

def signature(out: Path, generator: str) -> dict:
    return signature_extract.python_signature(out) if generator == "python" else signature_extract.typescript_signature(out)

def prepare_variants() -> list[tuple[str, str, str, Path]]:
    VAR.mkdir(parents=True, exist_ok=True)
    jobs = []
    for source in sorted(RAW.glob("spec_*.yaml")):
        sid = source.stem
        doc = yaml.safe_load(source.read_text(encoding="utf-8"))
        rev = copy.deepcopy(doc)
        rev["paths"] = dict(reversed(list((rev.get("paths") or {}).items())))
        for name, payload in (("original", doc), ("reverse_paths", rev)):
            target = VAR / f"{sid}__{name}.yaml"
            target.write_text(yaml.safe_dump(payload, sort_keys=False, allow_unicode=True), encoding="utf-8")
            for g in GENS:
                jobs.append((sid, name, g, target))
    return jobs

def run(job):
    sid, variant, generator, spec = job
    out = OUT / sid / variant / generator
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)
    p = subprocess.run([
        "java", "-Xmx640m", "-jar", str(JAR), "generate",
        "-i", str(spec), "-g", generator, "-o", str(out),
        "--global-property", "apiDocs=false,modelDocs=false,apiTests=false,modelTests=false",
    ], capture_output=True, text=True, timeout=180)
    s = signature(out, generator) if p.returncode == 0 else {}
    txt = json.dumps(s, sort_keys=True, separators=(",", ":"))
    return {
        "sample_id": sid,
        "variant": variant,
        "generator": generator,
        "generation_ok": p.returncode == 0,
        "projection_sha256": hashlib.sha256(txt.encode()).hexdigest(),
        "projection_record_count": len(s),
        "generation_error": (p.stderr or p.stdout)[-500:] if p.returncode else "",
    }

def main():
    jobs = prepare_variants()
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
        rows = list(ex.map(run, jobs))
    rows.sort(key=lambda r: (r["sample_id"], r["generator"], r["variant"]))
    RES.mkdir(exist_ok=True)
    with (RES / "path_robustness_722_run_results.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    lookup = {(r["sample_id"], r["generator"], r["variant"]): r for r in rows}
    pairs = []
    for source in sorted(RAW.glob("spec_*.yaml")):
        sid = source.stem
        for g in GENS:
            a = lookup[(sid, g, "original")]
            b = lookup[(sid, g, "reverse_paths")]
            pairs.append({
                "sample_id": sid,
                "generator": g,
                "generation_disagreement": a["generation_ok"] != b["generation_ok"],
                "projection_changed": a["generation_ok"] and b["generation_ok"] and a["projection_sha256"] != b["projection_sha256"],
            })
    with (RES / "path_robustness_722_pair_results.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(pairs[0])); w.writeheader(); w.writerows(pairs)
    ids = sorted({r["sample_id"] for r in pairs if r["projection_changed"]})
    by_backend = {g: sorted({r["sample_id"] for r in pairs if r["generator"] == g and r["projection_changed"]}) for g in GENS}
    summary = {
        "generator_version": "7.22.0",
        "generation_runs": len(rows),
        "generation_failures": sum(not r["generation_ok"] for r in rows),
        "affected_specs": len(ids),
        "affected_spec_ids": ids,
        "affected_ids_by_backend": by_backend,
    }
    (RES / "path_robustness_722_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
