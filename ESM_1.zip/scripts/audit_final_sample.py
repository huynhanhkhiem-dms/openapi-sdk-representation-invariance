#!/usr/bin/env python3
"""Audit the frozen 40-contract corpus against the manuscript's inclusion rules.

This script intentionally audits only the *included* corpus. The historical pre-screen
candidate/exclusion list was not retained and is therefore not reconstructed here.
"""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "data" / "data_manifest.csv"
RAW = ROOT / "data" / "raw_specs"
OUT_CSV = ROOT / "results" / "final_sample_eligibility_audit.csv"
OUT_JSON = ROOT / "results" / "final_sample_eligibility_summary.json"

MIN_BYTES = 2 * 1024
MAX_BYTES = 500 * 1024


def walk_count_refs_and_combinators(node: Any) -> tuple[int, int]:
    refs = 0
    combinators = 0
    if isinstance(node, dict):
        for k, v in node.items():
            if k == "$ref":
                refs += 1
            if k in {"allOf", "oneOf", "anyOf"}:
                combinators += 1
            r, c = walk_count_refs_and_combinators(v)
            refs += r
            combinators += c
    elif isinstance(node, list):
        for v in node:
            r, c = walk_count_refs_and_combinators(v)
            refs += r
            combinators += c
    return refs, combinators


def main() -> None:
    with MANIFEST.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    audited = []
    for row in rows:
        sid = row["sample_id"]
        path = RAW / f"{sid}.yaml"
        data = path.read_bytes()
        obj = yaml.safe_load(data)
        version = str(obj.get("openapi", "")) if isinstance(obj, dict) else ""
        schemas = (((obj or {}).get("components") or {}).get("schemas") or {}) if isinstance(obj, dict) else {}
        schema_count = len(schemas) if isinstance(schemas, dict) else 0
        refs, combinators = walk_count_refs_and_combinators(obj)
        digest = hashlib.sha256(data).hexdigest()
        audit = {
            "sample_id": sid,
            "repository_path": row["repository_path"],
            "bytes": len(data),
            "openapi_version": version,
            "schema_count": schema_count,
            "ref_count": refs,
            "combinator_count": combinators,
            "is_openapi_3x": version.startswith("3."),
            "size_2kb_to_500kb": MIN_BYTES <= len(data) <= MAX_BYTES,
            "at_least_3_component_schemas": schema_count >= 3,
            "has_ref_or_combinator": (refs + combinators) >= 1,
            "sha256_matches_manifest": digest == row["sha256"],
        }
        audit["eligible"] = all(
            audit[k]
            for k in [
                "is_openapi_3x",
                "size_2kb_to_500kb",
                "at_least_3_component_schemas",
                "has_ref_or_combinator",
                "sha256_matches_manifest",
            ]
        )
        audited.append(audit)

    fields = list(audited[0])
    with OUT_CSV.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(audited)

    summary = {
        "frozen_corpus_size": len(audited),
        "eligible_count": sum(bool(x["eligible"]) for x in audited),
        "all_included_contracts_pass_stated_eligibility": all(bool(x["eligible"]) for x in audited),
        "manifest_sha256_match_count": sum(bool(x["sha256_matches_manifest"]) for x in audited),
        "eligibility_rules": {
            "openapi": "3.x",
            "downloaded_size_bytes": [MIN_BYTES, MAX_BYTES],
            "minimum_component_schemas": 3,
            "requires_ref_or_schema_combinator": True,
        },
        "scope_note": "This audit verifies the frozen 40 included contracts. The historical pre-screen candidate/exclusion log was not retained, so this script does not claim to reconstruct that earlier screening frame.",
    }
    OUT_JSON.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
