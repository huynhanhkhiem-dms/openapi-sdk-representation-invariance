#!/usr/bin/env python3
from pathlib import Path
import csv,itertools,re,difflib
ROOT=Path(__file__).resolve().parents[1]; RAW=ROOT/'data'/'raw_specs'; OUT=ROOT/'results'
THRESH=0.75

def norm_lines(txt):
 return [re.sub(r'\s+',' ',x.strip()) for x in txt.splitlines() if x.strip()]
def shingles(lines,k=3):
 return {'\n'.join(lines[i:i+k]) for i in range(max(0,len(lines)-k+1))}
def jac(a,b): return len(a&b)/len(a|b) if (a|b) else 1.0
files={f'spec_{i:03d}':next(RAW.glob(f'spec_{i:03d}.*')) for i in range(1,41)}
lines={k:norm_lines(p.read_text(encoding='utf-8',errors='replace')) for k,p in files.items()}; sh={k:shingles(v) for k,v in lines.items()}
rows=[]
for a,b in itertools.combinations(files,2):
 j=jac(sh[a],sh[b])
 if j>=0.50:
  sm=difflib.SequenceMatcher(None,'\n'.join(lines[a]),'\n'.join(lines[b]),autojunk=False).ratio()
  rows.append({'sample_a':a,'sample_b':b,'three_line_shingle_jaccard':round(j,6),'sequence_matcher_ratio':round(sm,6),'above_threshold_0_75':j>=THRESH})
rows.sort(key=lambda r:r['three_line_shingle_jaccard'],reverse=True)
with (OUT/'near_duplicate_screen.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
# connected components at threshold
parent={k:k for k in files}
def find(x):
 while parent[x]!=x: parent[x]=parent[parent[x]]; x=parent[x]
 return x
def union(a,b):
 a,b=find(a),find(b)
 if a!=b: parent[b]=a
for r in rows:
 if r['above_threshold_0_75']: union(r['sample_a'],r['sample_b'])
clusters={}
for k in files: clusters.setdefault(find(k),[]).append(k)
cluster_rows=[]
for cid,members in enumerate(sorted(clusters.values(),key=lambda m:m[0]),1):
 for m in members: cluster_rows.append({'sample_id':m,'cluster_id':f'cluster_{cid:03d}','cluster_size':len(m),'members':'|'.join(members)})
with (OUT/'near_duplicate_clusters.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=cluster_rows[0].keys());w.writeheader();w.writerows(cluster_rows)
print('pairs >= threshold:',[(r['sample_a'],r['sample_b'],r['three_line_shingle_jaccard'],r['sequence_matcher_ratio']) for r in rows if r['above_threshold_0_75']]); print('clusters',len(clusters))
