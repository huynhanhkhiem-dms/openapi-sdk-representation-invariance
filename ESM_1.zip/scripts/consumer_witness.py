#!/usr/bin/env python3
from __future__ import annotations
import json, shutil, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'/'reduced'; OUT=ROOT/'consumer_witness_runs'; RES=ROOT/'results'; LOCAL_TSC=ROOT/'node_modules'/'.bin'/'tsc'
VERS=('7.22.0','7.25.0')
CONSUMER="""import { DefaultApi, DeleteFleetOperationRequest } from './apis/DefaultApi';
const api = new DefaultApi();
const req: DeleteFleetOperationRequest = { deleteFleetRequest: { fleet: 'arn:test' } };
void api.deleteFleet(req);
"""

def gen(version,case,spec):
 jar=ROOT/'tools'/f'openapi-generator-cli-{version}.jar'; out=OUT/version/case
 if out.exists(): shutil.rmtree(out)
 out.mkdir(parents=True,exist_ok=True)
 p=subprocess.run(['java','-Xmx640m','-jar',str(jar),'generate','-i',str(spec),'-g','typescript-fetch','-o',str(out),'--global-property','apiDocs=false,modelDocs=false,apiTests=false,modelTests=false'],capture_output=True,text=True,timeout=180)
 if p.returncode: raise RuntimeError((p.stderr or p.stdout)[-2000:])
 (out/'consumer.ts').write_text(CONSUMER,encoding='utf-8')
 c=subprocess.run([str(LOCAL_TSC if LOCAL_TSC.exists() else 'tsc'),'--noEmit','--target','ES2020','--module','commonjs','--lib','ES2020,DOM','--skipLibCheck','consumer.ts'],cwd=out,capture_output=True,text=True,timeout=180)
 return {'exit_code':c.returncode,'stdout':c.stdout[-2000:],'stderr':c.stderr[-2000:]}
def main():
 base=DATA/'reduced_paths_orig__schemas_orig.yaml'; rev=DATA/'reduced_paths_rev__schemas_orig.yaml'
 if not base.exists() or not rev.exists():
  # factorial script materializes these names
  subprocess.run(['python',str(ROOT/'scripts'/'reduced_case_factorial.py')],check=True,cwd=ROOT)
 rows=[]
 for v in VERS:
  b=gen(v,'baseline',base); r=gen(v,'path_reversed',rev)
  rows.append({'version':v,'baseline':b,'path_reversed':r,'witness_break':b['exit_code']==0 and r['exit_code']!=0})
 out={'typescript_compiler':subprocess.run([str(LOCAL_TSC if LOCAL_TSC.exists() else 'tsc'),'--version'],capture_output=True,text=True).stdout.strip(),'consumer_source':CONSUMER,'checks':rows,'all_versions_show_break':all(x['witness_break'] for x in rows)}
 RES.mkdir(exist_ok=True);(RES/'consumer_witness_summary.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
 print(json.dumps(out,indent=2))
if __name__=='__main__':main()
