from pathlib import Path
import csv,json
ROOT=Path(__file__).resolve().parents[1]; R=ROOT/'results'
EXPECTED={'spec_009','spec_012','spec_013','spec_017','spec_019','spec_025','spec_034','spec_036','spec_037','spec_038'}
checks={}
def rows(name):
 with (R/name).open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
def b(x):return str(x).strip().lower() in {'true','1','yes'}
main=rows('main_725_projection_results.csv'); pairs=rows('main_725_pair_projection_results.csv')
checks['fresh_main_runs_480']=len(main)==480
checks['fresh_main_generation_ok_480']=all(b(x['generation_ok']) for x in main)
checks['main_pairs_400']=len(pairs)==400
checks['equivalence_gate_400_400']=all(b(x['semantic_hash_matches_baseline']) for x in pairs)
expected={'format_json':0,'reverse_paths':10,'reverse_component_schemas':5,'recursive_reverse':21,'canonical_sorted':1}; affected={}
for v,n in expected.items():
 ids={x['sample_id'] for x in pairs if x['variant']==v and b(x['projection_changed'])};affected[v]=sorted(ids);checks[f'{v}_projection_changed_{n}']=len(ids)==n
checks['reverse_paths_exact_ids']=set(affected['reverse_paths'])==EXPECTED
checks['format_control_80_80_projection_stable']=sum(1 for x in pairs if x['variant']=='format_json' and not b(x['projection_changed']))==80
# New whole-tree diagnostic: headline reverse_paths exactly aligns with tree paths/content and no file-count changes.
rp=[x for x in pairs if x['variant']=='reverse_paths']
checks['reverse_paths_tree_content_exact_same_10']= {x['sample_id'] for x in rp if b(x['tree_content_changed'])}==EXPECTED
checks['reverse_paths_tree_paths_exact_same_10']= {x['sample_id'] for x in rp if b(x['tree_paths_changed'])}==EXPECTED
checks['reverse_paths_file_count_stable_80_80']=all(int(x['whole_project_file_count_change'])==0 for x in rp)
# spec_023 fresh full rerun
r23=[x for x in main if x['sample_id']=='spec_023' and x['generator']=='python']
checks['spec023_six_variants']=len(r23)==6
checks['spec023_all_127_files']=all(int(x['whole_project_file_count'])==127 for x in r23)
checks['spec023_projection_same_all_six']=len({x['projection_sha256'] for x in r23})==1
# 7.22 replication
p722=rows('path_robustness_722_pair_results.csv'); key='projection_changed' if 'projection_changed' in p722[0] else 'signature_changed'
checks['path_722_exact_same_ids']={x['sample_id'] for x in p722 if b(x[key])}==EXPECTED
# semantic-scope + dedup sensitivity
scope=json.loads((R/'semantic_scope_and_dedup_summary.json').read_text())
checks['strict_oas_ambiguity_4']=scope['strict_oas_ambiguous_template_overlap_contracts']==4
checks['strict_semantics_clean_36_8']=scope['semantics_clean_contracts_under_strict_screen']==36 and scope['semantics_clean_reverse_path_drift_contracts']==8
checks['dedup_full_39_9']=scope['deduplicated_full_benchmark_families']==39 and scope['deduplicated_reverse_path_drift_families']==9
checks['dedup_clean_35_7']=scope['deduplicated_semantics_clean_families']==35 and scope['deduplicated_semantics_clean_drift_families']==7
checks['near_duplicate_pair_only_019_034']=len(scope['near_duplicate_pairs_above_0_75'])==1 and {scope['near_duplicate_pairs_above_0_75'][0]['sample_a'],scope['near_duplicate_pairs_above_0_75'][0]['sample_b']}=={'spec_019','spec_034'}
# provider design resolution
powr=rows('provider_conditioned_design_resolution.csv'); headline=next(x for x in powr if x['feature']=='any_path_local_inline_model')
checks['headline_min_attainable_p_1_6']=abs(float(headline['minimum_attainable_one_sided_p'])-1/6)<1e-12 and not b(headline['can_reach_alpha_0_05'])
# sortOutput: output sorting occurs after resolver differences, so does not collapse ten affected cases
so=rows('sortoutput_preprocess_725.csv')
checks['sortoutput_10_cases']=len(so)==10 and {x['sample_id'] for x in so}==EXPECTED
checks['sortoutput_not_collapse_10_10']=all(not b(x['bytes_equal']) and not b(x['semantic_equal']) for x in so)
# title migration + repair
tm=json.loads((R/'title_repair_migration.json').read_text()); checks['title_adoption_migration_4_4']=len(tm)==4 and all(x['projection_changed_on_title_adoption'] for x in tm)
tr=json.loads((R/'title_repair_summary.json').read_text());checks['title_repair_summary_present']=bool(tr)
# mitigation
m25=rows('mitigation_extension/sort_model_properties_7.25.0.csv'); k25='projection_changed' if 'projection_changed' in m25[0] else 'signature_changed'
checks['sort_model_properties_725_80_rows']=len(m25)==80
checks['sort_model_properties_725_same_10']={x['sample_id'] for x in m25 if b(x[k25])}==EXPECTED
m22=rows('mitigation_extension/sort_model_properties_7.22.0_affected_cases.csv');k22='projection_changed' if 'projection_changed' in m22[0] else 'signature_changed'
checks['sort_model_properties_722_20_rows']=len(m22)==20
checks['sort_model_properties_722_20_20_changed']=all(b(x[k22]) for x in m22)
# other frozen gates
checks['eligibility_40']=len(rows('final_sample_eligibility_audit.csv'))==40
out={'check_type':'fresh-regeneration consistency + construct/provenance/sensitivity checks','all_pass':all(checks.values()),'checks':checks,'headline_projection_affected_ids':affected,'note':'The 7.25 main table is rebuilt from a fresh 480-generation clean run with whole-project tree hashes. These checks are consistency/provenance checks; 7.22 and targeted mitigation/repair experiments use their separately pinned runs.'}
print(json.dumps(out,indent=2));(R/'verification_output.txt').write_text(json.dumps(out,indent=2)+'\n');(R/'final_consistency_and_provenance_summary.json').write_text(json.dumps(out,indent=2)+'\n');raise SystemExit(0 if out['all_pass'] else 1)
