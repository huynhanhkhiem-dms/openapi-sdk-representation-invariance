#!/usr/bin/env python3
"""Deterministic generated-source declaration projection used by the replication scripts.

The projection is intentionally syntactic and is not a complete package-level export model.
"""
from __future__ import annotations
import ast
import json
import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def _ast_text(node) -> str:
    if node is None:
        return "<inferred>"
    try:
        return ast.unparse(node).replace(" ", "")
    except Exception:
        return "<?>"

def _py_arg_signature(arg: ast.arg, default: bool = False, prefix: str = "") -> str:
    return f"{prefix}{arg.arg}:{_ast_text(arg.annotation)}" + ("=default" if default else "")

def _python_callable_signature(node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    a = node.args
    parts: list[str] = []
    positional = list(a.posonlyargs) + list(a.args)
    defaults = [False] * (len(positional) - len(a.defaults)) + [True] * len(a.defaults)
    for i, (arg, has_default) in enumerate(zip(positional, defaults)):
        if arg.arg in {"self", "cls"}:
            continue
        prefix = "/" if i < len(a.posonlyargs) else ""
        parts.append(_py_arg_signature(arg, has_default, prefix))
    if a.vararg:
        parts.append(_py_arg_signature(a.vararg, False, "*"))
    elif a.kwonlyargs:
        parts.append("*")
    for arg, default in zip(a.kwonlyargs, a.kw_defaults):
        parts.append(_py_arg_signature(arg, default is not None))
    if a.kwarg:
        parts.append(_py_arg_signature(a.kwarg, False, "**"))
    return f"{node.name}({','.join(parts)})->{_ast_text(node.returns)}"

def python_signature(output: Path) -> dict:
    result = {}
    for path in sorted(output.rglob("*.py")):
        rel = path.relative_to(output)
        if any(part in {"test", "tests", ".openapi-generator"} for part in rel.parts):
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        public = {}
        for node in tree.body:
            if isinstance(node, ast.ClassDef) and not node.name.startswith("_"):
                fields, methods = [], []
                bases = sorted(_ast_text(b) for b in node.bases)
                for item in node.body:
                    if isinstance(item, ast.AnnAssign) and isinstance(item.target, ast.Name) and not item.target.id.startswith("_"):
                        fields.append(f"{item.target.id}:{_ast_text(item.annotation)}")
                    elif isinstance(item, ast.Assign):
                        for tgt in item.targets:
                            if isinstance(tgt, ast.Name) and not tgt.id.startswith("_"):
                                fields.append(f"{tgt.id}:<inferred>")
                    elif isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) and not item.name.startswith("_"):
                        methods.append(_python_callable_signature(item))
                public[f"class {node.name}"] = {
                    "bases": bases,
                    "fields": sorted(set(fields)),
                    "methods": sorted(set(methods)),
                }
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and not node.name.startswith("_"):
                public[f"function {_python_callable_signature(node)}"] = True
        if public:
            result[str(rel).replace(os.sep, "/")] = public
    return result

def typescript_signature(output: Path) -> dict:
    extractor = ROOT / "scripts" / "extract_typescript_api.js"
    proc = subprocess.run(
        ["node", str(extractor), str(output)],
        capture_output=True,
        text=True,
        timeout=60,
    )
    if proc.returncode != 0:
        raise RuntimeError(f"TypeScript signature extraction failed: {proc.stderr[-1000:]}")
    return json.loads(proc.stdout or "{}")
