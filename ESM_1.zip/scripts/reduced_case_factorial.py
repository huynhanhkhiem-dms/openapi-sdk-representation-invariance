#!/usr/bin/env python3
"""Reproduce the 2 x 2 reduced path-order x schema-order experiment."""
from __future__ import annotations
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
import signature_extract

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "reduced"
OUTROOT = ROOT / "reduced_factorial_runs"
RESULTS = ROOT / "results"
VERSIONS = ("7.22.0", "7.25.0")
GENERATORS = ("python", "typescript-fetch")
CASES = (
    "paths_orig__schemas_orig",
    "paths_orig__schemas_rev",
    "paths_rev__schemas_orig",
    "paths_rev__schemas_rev",
)

def canonical_hash(doc) -> str:
    return hashlib.sha256(json.dumps(doc, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

def load_cases():
    cases = {}
    hashes = {}
    for case in CASES:
        p = DATA / f"reduced_{case}.yaml"
        doc = yaml.safe_load(p.read_text(encoding="utf-8"))
        cases[case] = p
        hashes[case] = canonical_hash(doc)
    assert len(set(hashes.values())) == 1, hashes
    return cases, hashes

def flatten_strings(value):
    if isinstance(value, dict):
        for k, v in value.items():
            yield str(k); yield from flatten_strings(v)
    elif isinstance(value, list):
        for v in value: yield from flatten_strings(v)
    elif isinstance(value, str):
        yield value

def evidence(sig):
    strings = list(flatten_strings(sig))
    hits = [s for s in strings if any(t in s.lower() for t in ("deletefleet", "describefleet", "delete_fleet", "describe_fleet"))]
    return sorted(set(hits))

def combined_signature(out: Path, generator: str) -> dict:
    return signature_extract.python_signature(out) if generator == "python" else signature_extract.typescript_signature(out)

def generate(spec: Path, version: str, generator: str, case: str) -> dict:
    jar = ROOT / "tools" / f"openapi-generator-cli-{version}.jar"
    if not jar.exists():
        raise FileNotFoundError(f"Missing {jar}")
    out = OUTROOT / version / case / generator
    if out.exists(): shutil.rmtree(out)
    out.mkdir(parents=True)
    cmd = [
        "java", "-Xmx640m", "-jar", str(jar), "generate",
        "-i", str(spec), "-g", generator, "-o", str(out),
        "--global-property", "apiDocs=false,modelDocs=false,apiTests=false,modelTests=false",
    ]
    gen = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
    if gen.returncode:
        raise RuntimeError((gen.stderr or gen.stdout)[-2000:])
    sig = combined_signature(out, generator)
    txt = json.dumps(sig, sort_keys=True, separators=(",", ":"))
    return {"signature_sha256": hashlib.sha256(txt.encode()).hexdigest(), "evidence": evidence(sig)}

def main():
    cases, hashes = load_cases(); rows = []
    for version in VERSIONS:
        for generator in GENERATORS:
            for case, spec in cases.items():
                rows.append({"version": version, "generator": generator, "case": case, "semantic_sha256": hashes[case], **generate(spec, version, generator, case)})
    baseline = {(r["version"], r["generator"]): r for r in rows if r["case"] == "paths_orig__schemas_orig"}
    compact = []
    for r in rows:
        b = baseline[(r["version"], r["generator"])]
        compact.append(r | {"changed_vs_baseline": r["signature_sha256"] != b["signature_sha256"]})
    causal = {}
    for version in VERSIONS:
        causal[version] = {}
        for generator in GENERATORS:
            d = {r["case"]: r for r in compact if r["version"] == version and r["generator"] == generator}
            path_only = bool(d["paths_rev__schemas_orig"]["changed_vs_baseline"])
            schema_only = bool(d["paths_orig__schemas_rev"]["changed_vs_baseline"])
            both = bool(d["paths_rev__schemas_rev"]["changed_vs_baseline"])
            classification = (
                "path_sufficient" if path_only and not schema_only else
                "schema_sufficient" if schema_only and not path_only else
                "both_individually_sufficient" if path_only and schema_only else
                "interaction_only" if both else "no_effect"
            )
            causal[version][generator] = {
                "path_order_alone_changes_signature": path_only,
                "schema_order_alone_changes_signature": schema_only,
                "joint_reversal_changes_signature": both,
                "classification": classification,
                "baseline_evidence": d["paths_orig__schemas_orig"]["evidence"],
                "path_only_evidence": d["paths_rev__schemas_orig"]["evidence"],
                "schema_only_evidence": d["paths_orig__schemas_rev"]["evidence"],
                "joint_evidence": d["paths_rev__schemas_rev"]["evidence"],
            }
    out = {
        "semantic_hash_identical": len(set(hashes.values())) == 1,
        "semantic_sha256": next(iter(hashes.values())),
        "design": "2x2 path-order x components.schemas-order",
        "checks": compact,
        "causal_pattern": causal,
    }
    RESULTS.mkdir(exist_ok=True)
    (RESULTS / "reduced_factorial_summary.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    main()
