#!/usr/bin/env python3
"""Regenerate normalized declaration projections for the reverse-path cases.

This script is intentionally a regeneration utility, not a substitute for submitted
results. It requires the pinned OpenAPI Generator JAR listed in TOOL_VERSIONS.txt.
It writes human-readable projection JSON for the source-order-preserving baseline
and reverse_paths treatment, plus deterministic unified diffs.
"""
from __future__ import annotations

import argparse
import difflib
import json
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import signature_extract  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
VARIANTS = ROOT / "data" / "main_variants"
OUTROOT = ROOT / "results" / "projection_evidence"
DEFAULT_CASES = ["spec_009", "spec_012", "spec_013", "spec_017", "spec_019",
                 "spec_025", "spec_034", "spec_036", "spec_037", "spec_038"]
GENERATORS = ("python", "typescript-fetch")


def variant_path(sample_id: str, variant: str) -> Path:
    hits = list(VARIANTS.glob(f"{sample_id}__{variant}.*"))
    if len(hits) != 1:
        raise RuntimeError(f"Expected one file for {sample_id}/{variant}, found {hits}")
    return hits[0]


def projection(path: Path, generator: str) -> dict:
    return signature_extract.python_signature(path) if generator == "python" else signature_extract.typescript_signature(path)


def generate(jar: Path, spec: Path, generator: str, out: Path) -> None:
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    cmd = [
        "java", "-Xmx640m", "-jar", str(jar), "generate",
        "-i", str(spec), "-g", generator, "-o", str(out),
        "--global-property", "apiDocs=false,modelDocs=false,apiTests=false,modelTests=false",
    ]
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=240)
    if p.returncode:
        raise RuntimeError(f"Generation failed for {spec.name}/{generator}:\n{(p.stderr or p.stdout)[-2000:]}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--version", default="7.25.0")
    ap.add_argument("--cases", nargs="*", default=DEFAULT_CASES)
    args = ap.parse_args()
    jar = ROOT / "tools" / f"openapi-generator-cli-{args.version}.jar"
    if not jar.exists():
        raise SystemExit(f"Missing {jar}. Place the pinned JAR under tools/ first.")

    manifest = []
    temp = ROOT / "projection_runs"
    for sid in args.cases:
        for gen in GENERATORS:
            docs = {}
            for variant in ("original", "reverse_paths"):
                runout = temp / args.version / sid / gen / variant
                generate(jar, variant_path(sid, variant), gen, runout)
                docs[variant] = projection(runout, gen)
                dest = OUTROOT / args.version / sid / gen
                dest.mkdir(parents=True, exist_ok=True)
                prefix = f"{sid}_{gen.replace('-', '_')}"
                fname = (f"{prefix}_source_order_baseline.json" if variant == "original"
                         else f"{prefix}_reverse_paths.json")
                (dest / fname).write_text(
                    json.dumps(docs[variant], ensure_ascii=False, indent=2, sort_keys=True) + "\n",
                    encoding="utf-8",
                )
            base = json.dumps(docs["original"], ensure_ascii=False, indent=2, sort_keys=True).splitlines(True)
            rev = json.dumps(docs["reverse_paths"], ensure_ascii=False, indent=2, sort_keys=True).splitlines(True)
            diff = "".join(difflib.unified_diff(base, rev, fromfile="source_order_baseline", tofile="reverse_paths"))
            dest = OUTROOT / args.version / sid / gen
            prefix = f"{sid}_{gen.replace('-', '_')}"
            diff_file = dest / f"{prefix}_projection.diff"
            diff_file.write_text(diff, encoding="utf-8")
            manifest.append({
                "sample_id": sid, "generator": gen, "version": args.version,
                "projection_changed": docs["original"] != docs["reverse_paths"],
                "baseline_entities": len(docs["original"]),
                "reverse_entities": len(docs["reverse_paths"]),
                "diff_path": str(diff_file.relative_to(ROOT)),
            })
    OUTROOT.mkdir(parents=True, exist_ok=True)
    (OUTROOT / f"manifest_{args.version}.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
