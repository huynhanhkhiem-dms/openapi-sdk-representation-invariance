#!/usr/bin/env python3
"""Reproduce the 40-contract OpenAPI Generator 7.25.0 main experiment."""

from __future__ import annotations

import ast
import concurrent.futures
import copy
import csv
import datetime as dt
import hashlib
import json
import shutil
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
import signature_extract  # noqa: E402


ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw_specs"
VARIANTS = ROOT / "data" / "main_variants"
RUNS = ROOT / "main_runs"
RESULTS = ROOT / "results"
LOCAL_TSC = ROOT / "node_modules" / ".bin" / "tsc"
GENERATORS = ("python", "typescript-fetch")
MAIN_VERSION = "7.25.0"
MAIN_N = 40


def tsc_path() -> str:
    if LOCAL_TSC.exists():
        return str(LOCAL_TSC)
    found = shutil.which("tsc")
    if found:
        return found
    raise RuntimeError("TypeScript compiler not found. Run `npm ci` first.")


def tool_version(cmd: list[str]) -> str:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        return (p.stdout or p.stderr).strip().splitlines()[0] if (p.stdout or p.stderr).strip() else "unknown"
    except Exception:
        return "unknown"


def canonical_bytes(doc: dict) -> bytes:
    return json.dumps(doc, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


def normalize_scalars(value):
    if isinstance(value, dict):
        return {k: normalize_scalars(v) for k, v in value.items()}
    if isinstance(value, list):
        return [normalize_scalars(v) for v in value]
    if isinstance(value, (dt.date, dt.datetime)):
        return value.isoformat()
    return value


def reverse_dict(d: dict) -> dict:
    return {k: v for k, v in reversed(list(d.items()))}


def recursive_reverse(value):
    if isinstance(value, dict):
        return {k: recursive_reverse(v) for k, v in reversed(list(value.items()))}
    if isinstance(value, list):
        return [recursive_reverse(v) for v in value]
    return value


def sorted_mappings(value):
    if isinstance(value, dict):
        return {k: sorted_mappings(value[k]) for k in sorted(value)}
    if isinstance(value, list):
        return [sorted_mappings(v) for v in value]
    return value


def make_variants() -> list[dict]:
    VARIANTS.mkdir(parents=True, exist_ok=True)
    rows = []
    for source in sorted(RAW.glob("spec_*.yaml"))[:MAIN_N]:
        doc = normalize_scalars(yaml.safe_load(source.read_text(encoding="utf-8")))
        format_json = doc
        reverse_paths = copy.deepcopy(doc)
        reverse_paths["paths"] = reverse_dict(reverse_paths.get("paths") or {})
        reverse_schemas = copy.deepcopy(doc)
        components = reverse_schemas.setdefault("components", {})
        components["schemas"] = reverse_dict(components.get("schemas") or {})
        recursive = recursive_reverse(doc)
        canonical = sorted_mappings(doc)
        payloads = {
            "original": (doc, ".yaml"),
            "format_json": (format_json, ".json"),
            "reverse_paths": (reverse_paths, ".yaml"),
            "reverse_component_schemas": (reverse_schemas, ".yaml"),
            "recursive_reverse": (recursive, ".yaml"),
            "canonical_sorted": (canonical, ".json"),
        }
        semantic_hash = hashlib.sha256(canonical_bytes(doc)).hexdigest()
        for name, (payload, suffix) in payloads.items():
            target = VARIANTS / f"{source.stem}__{name}{suffix}"
            if suffix == ".json":
                target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            else:
                target.write_text(yaml.safe_dump(payload, sort_keys=False, allow_unicode=True), encoding="utf-8")
            rows.append({
                "sample_id": source.stem,
                "variant": name,
                "path": str(target.relative_to(ROOT)),
                "byte_sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
                "semantic_sha256": hashlib.sha256(canonical_bytes(payload)).hexdigest(),
                "semantic_hash_matches_original": hashlib.sha256(canonical_bytes(payload)).hexdigest() == semantic_hash,
            })
    with (ROOT / "data" / "main_variant_manifest.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return rows


def combined_signature(out: Path, generator: str) -> dict:
    if generator == "python":
        return signature_extract.python_signature(out)
    return signature_extract.typescript_signature(out)


def run_one(job: dict) -> dict:
    sample_id = job["sample_id"]
    variant = job["variant"]
    generator = job["generator"]
    version = job["version"]
    spec = ROOT / job["path"]
    jar = ROOT / "tools" / f"openapi-generator-cli-{version}.jar"
    out = RUNS / version / sample_id / variant / generator
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)
    cmd = [
        "java", "-Xmx640m", "-jar", str(jar), "generate",
        "-i", str(spec), "-g", generator, "-o", str(out),
        "--global-property", "apiDocs=false,modelDocs=false,apiTests=false,modelTests=false",
    ]
    generated = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
    if generated.returncode == 0:
        signature = combined_signature(out, generator)
    else:
        signature = {}
    signature_text = json.dumps(signature, sort_keys=True, separators=(",", ":"))
    return {
        "sample_id": sample_id,
        "variant": variant,
        "generator": generator,
        "generator_version": version,
        "semantic_hash_matches_original": job["semantic_hash_matches_original"],
        "generation_ok": generated.returncode == 0,
        "projection_sha256": hashlib.sha256(signature_text.encode()).hexdigest(),
        "projection_record_count": len(signature),
        "generation_error": (generated.stderr or generated.stdout)[-800:] if generated.returncode else "",
    }


def compare(rows: list[dict]) -> list[dict]:
    lookup = {(r["sample_id"], r["generator"], r["generator_version"], r["variant"]): r for r in rows}
    pairs = []
    for row in rows:
        if row["variant"] == "original":
            continue
        base = lookup[(row["sample_id"], row["generator"], row["generator_version"], "original")]
        pairs.append({
            "sample_id": row["sample_id"],
            "variant": row["variant"],
            "generator": row["generator"],
            "generator_version": row["generator_version"],
            "semantic_hash_matches_original": row["semantic_hash_matches_original"],
            "generation_disagreement": row["generation_ok"] != base["generation_ok"],
            "projection_changed": row["generation_ok"] and base["generation_ok"] and row["projection_sha256"] != base["projection_sha256"],
            "projection_record_count_change": row["projection_record_count"] - base["projection_record_count"],
        })
    return pairs


def main() -> None:
    variants = make_variants()
    main_jobs = [
        {**v, "generator": g, "version": MAIN_VERSION}
        for v in variants for g in GENERATORS
    ]
    jobs = main_jobs
    RUNS.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        rows = list(pool.map(run_one, jobs))
    rows.sort(key=lambda r: (r["generator_version"], r["sample_id"], r["generator"], r["variant"]))
    with (RESULTS / "main_725_projection_results.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    pairs = compare(rows)
    with (RESULTS / "main_725_pair_projection_results.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(pairs[0]))
        writer.writeheader(); writer.writerows(pairs)

    current_pairs = pairs
    by_variant = {}
    for variant in sorted({p["variant"] for p in current_pairs}):
        subset = [p for p in current_pairs if p["variant"] == variant]
        by_variant[variant] = {
            "pairs": len(subset),
            "specs_with_projection_change": len({p["sample_id"] for p in subset if p["projection_changed"]}),
            "backend_pairs_with_projection_change": sum(p["projection_changed"] for p in subset),
            "generation_disagreements": sum(p["generation_disagreement"] for p in subset),
        }
    summary = {
        "generator_version": MAIN_VERSION,
        "specifications": MAIN_N,
        "backends": list(GENERATORS),
        "typescript_compiler": tool_version([tsc_path(), "--version"]),
        "java_runtime": tool_version(["java", "-version"]),
        "total_generation_runs": len(rows),
        "semantic_hash_mismatches": sum(not r["semantic_hash_matches_original"] for r in rows),
        "generation_failures": sum(not r["generation_ok"] for r in rows),
        "by_variant": by_variant,
    }
    (RESULTS / "main_725_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
