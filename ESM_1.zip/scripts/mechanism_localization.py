#!/usr/bin/env python3
"""Exploratory localization of reverse-path drift to path-local inline model candidates.

This analysis is explicitly post hoc and mechanism-oriented. It does not estimate
population risk from the non-probability 40-contract sample.
"""
from __future__ import annotations
import hashlib, json
from collections import defaultdict
from pathlib import Path
import pandas as pd
import yaml
from scipy.stats import fisher_exact

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw_specs"
RES = ROOT / "results"
HTTP = {"get", "put", "post", "delete", "patch", "options", "head", "trace"}
ANNOTATION_KEYS = {"description", "example", "examples", "title", "externalDocs", "deprecated"}


def strip_annotations(x):
    if isinstance(x, dict):
        return {k: strip_annotations(v) for k, v in x.items() if k not in ANNOTATION_KEYS}
    if isinstance(x, list):
        return [strip_annotations(v) for v in x]
    return x


def schema_hash(schema: dict) -> str:
    payload = json.dumps(strip_annotations(schema), sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(payload.encode()).hexdigest()


def is_inline_model_candidate(schema) -> bool:
    if not isinstance(schema, dict) or "$ref" in schema:
        return False
    if schema.get("type") == "object" or "properties" in schema or any(k in schema for k in ("allOf", "oneOf", "anyOf")):
        return True
    if schema.get("type") == "array" and isinstance(schema.get("items"), dict):
        return is_inline_model_candidate(schema["items"])
    return False


def occurrences(doc: dict) -> list[dict]:
    out = []
    for path, item in (doc.get("paths") or {}).items():
        if not isinstance(item, dict):
            continue
        scopes = [("PATH", item)] + [(m.upper(), op) for m, op in item.items() if m in HTTP and isinstance(op, dict)]
        for method, op in scopes:
            operation_id = op.get("operationId") if isinstance(op, dict) else None
            for parameter in op.get("parameters") or []:
                if isinstance(parameter, dict) and is_inline_model_candidate(parameter.get("schema")):
                    s = parameter["schema"]
                    out.append({"path": path, "method": method, "operation_id": operation_id, "context": "parameter", "schema_hash": schema_hash(s)})
            rb = op.get("requestBody")
            if isinstance(rb, dict):
                for media in (rb.get("content") or {}).values():
                    if isinstance(media, dict) and is_inline_model_candidate(media.get("schema")):
                        s = media["schema"]
                        out.append({"path": path, "method": method, "operation_id": operation_id, "context": "requestBody", "schema_hash": schema_hash(s)})
            for response in (op.get("responses") or {}).values():
                if not isinstance(response, dict):
                    continue
                for media in (response.get("content") or {}).values():
                    if isinstance(media, dict) and is_inline_model_candidate(media.get("schema")):
                        s = media["schema"]
                        out.append({"path": path, "method": method, "operation_id": operation_id, "context": "response", "schema_hash": schema_hash(s)})
    return out


def holm(pvalues: list[float]) -> list[float]:
    order = sorted(range(len(pvalues)), key=lambda i: pvalues[i])
    adjusted = [0.0] * len(pvalues)
    running = 0.0
    m = len(pvalues)
    for rank, idx in enumerate(order):
        val = min(1.0, (m-rank) * pvalues[idx])
        running = max(running, val)
        adjusted[idx] = running
    return adjusted


def main() -> None:
    pair = pd.read_csv(RES / "main_725_pair_results.csv")
    path = pair[pair["variant"].eq("reverse_paths")].copy()
    changed = path.assign(_changed=path["signature_changed"].astype(str).str.lower().eq("true")).groupby("sample_id")["_changed"].max().astype(int)

    rows = []
    for source in sorted(RAW.glob("spec_*.yaml")):
        doc = yaml.safe_load(source.read_text(encoding="utf-8"))
        rec = occurrences(doc)
        groups = defaultdict(list)
        for r in rec:
            groups[r["schema_hash"]].append(r)
        cross_path = [g for g in groups.values() if len({r["path"] for r in g}) > 1]
        rows.append({
            "sample_id": source.stem,
            "path_drift": int(changed[source.stem]),
            "path_local_inline_models": len(rec),
            "request_inline_models": sum(r["context"] == "requestBody" for r in rec),
            "response_inline_models": sum(r["context"] == "response" for r in rec),
            "parameter_inline_models": sum(r["context"] == "parameter" for r in rec),
            "cross_path_duplicate_model_groups": len(cross_path),
        })
    df = pd.DataFrame(rows)
    df.to_csv(RES / "mechanism_localization.csv", index=False)

    tests = []
    for label, col in [
        ("any_path_local_inline_model", "path_local_inline_models"),
        ("any_request_inline_model", "request_inline_models"),
        ("any_cross_path_duplicate_model_group", "cross_path_duplicate_model_groups"),
    ]:
        present = df[col] > 0
        a = int(((present) & (df.path_drift == 1)).sum())  # feature+, drift+
        b = int(((present) & (df.path_drift == 0)).sum())  # feature+, drift-
        c = int(((~present) & (df.path_drift == 1)).sum()) # feature-, drift+
        d = int(((~present) & (df.path_drift == 0)).sum()) # feature-, drift-
        odds, p = fisher_exact([[a, b], [c, d]], alternative="two-sided")
        tests.append({"feature": label, "drift_feature_present": a, "stable_feature_present": b,
                      "drift_feature_absent": c, "stable_feature_absent": d,
                      "odds_ratio": None if odds == float("inf") else float(odds), "fisher_p": float(p)})
    adj = holm([t["fisher_p"] for t in tests])
    for t, ap in zip(tests, adj):
        t["holm_adjusted_p"] = float(ap)

    summary = {
        "analysis_status": "exploratory_post_hoc_mechanism_localization",
        "sample_size": int(len(df)),
        "path_drift_specs": int(df.path_drift.sum()),
        "stable_specs": int((df.path_drift == 0).sum()),
        "tests": tests,
        "interpretation": "Within this fixed sample, every reverse-path-drift case contains at least one path-local inline model candidate. The association is mechanism-localization evidence, not a population risk estimate or proof of causality."
    }
    (RES / "mechanism_localization_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
